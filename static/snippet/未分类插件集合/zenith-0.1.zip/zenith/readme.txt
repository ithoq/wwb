Documentations are available at http://devpress.com/themes/zenith/

	* Note: Docs and support are available to DevPress members only.

Resources:

	* Several scripts were used in this theme and have additional licenses.
	
	* Fonts: (all fonts are licensed under OFL license at http://scripts.sil.org/OFL )
		* Fanwood
			* Link: http://www.google.com/webfonts/specimen/Fanwood
		* Goudy
			* Link: http://www.google.com/webfonts/specimen/Goudy+Bookletter+1911
		* Raleway
			* Link: http://www.google.com/webfonts/specimen/Raleway