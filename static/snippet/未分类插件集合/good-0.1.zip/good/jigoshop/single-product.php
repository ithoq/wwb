<?php
/**
 * Product template
 *
 * DISCLAIMER
 *
 * Do not edit or add directly to this file if you wish to upgrade Jigoshop to newer
 * versions in the future. If you wish to customise Jigoshop core for your needs,
 * please use our GitHub repository to publish essential changes for consideration.
 *
 * @package    Jigoshop
 * @category   Catalog
 * @author     Jigowatt
 * @copyright  Copyright (c) 2011 Jigowatt Ltd.
 * @license    http://jigoshop.com/license/commercial-edition
 */
 ?>
 
<?php get_header('shop'); ?>
	  
<?php do_action('jigoshop_before_main_content'); ?>

	<?php if ( current_theme_supports( 'breadcrumb-trail' ) ) breadcrumb_trail( array( 'before' => __( 'Browsing:', 'good' ), 'separator' => '&raquo;' ) ); ?>

	<?php if ( have_posts() ) while ( have_posts() ) : the_post(); global $_product; $_product = &new jigoshop_product( $post->ID ); ?>
		
	
		<div id="post-<?php the_ID(); ?>" class="<?php hybrid_entry_class(); ?>">
		
			<?php do_action( 'jigoshop_before_single_product', $post, $_product ); ?>
		
			<div class="entry-product-header">
				<?php do_action( 'jigoshop_before_single_product_summary', $post, $_product ); ?>
			
				<div class="product-summary">
					<h1 class="product-title"><?php the_title(); ?></h1>
						<div class="product-summary-content">
					<?php do_action( 'jigoshop_template_single_summary', $post, $_product ); ?>
						</div><!-- .product-summary-content -->
				</div>
				
				<div class="clear"></div>
			
			</div><!-- .product-header -->
			
			<div class="entry-content">
				<?php do_action( 'jigoshop_after_single_product_summary', $post, $_product ); ?>
			</div><!-- .entry-content -->
			
			<?php do_action( 'jigoshop_after_single_product', $post, $_product ); ?>
	
		</div><!-- .hentry -->
	
	<?php endwhile; ?>

<?php do_action( 'jigoshop_after_main_content' ); ?>

<?php get_footer( 'shop' ); ?>