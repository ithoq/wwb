<?php
/**
 * Header Sidebar Template
 *
 * Displays widgets for the header dynamic sidebar if any have been added to the sidebar through the 
 * widgets screen in the admin by the user.  Otherwise, nothing is displayed.
 *
 * @package Good
 * @subpackage Template
 */

if ( is_active_sidebar( 'header' ) ) : ?>

	<?php do_atomic( 'before_sidebar_header' ); // good_before_sidebar_header ?>

	<div id="sidebar-header" class="sidebar">

		<?php do_atomic( 'open_sidebar_header' ); // good_open_sidebar_header ?>

		<?php dynamic_sidebar( 'header' ); ?>

		<?php do_atomic( 'close_sidebar_header' ); // good_close_sidebar_header ?>

	</div><!-- #sidebar-header .aside -->

	<?php do_atomic( 'after_sidebar_header' ); // good_after_sidebar_header ?>

<?php endif; ?>