						<?php echo apply_atomic_shortcode( 'entry_title', '[entry-title]' ); ?>

						<?php echo apply_atomic_shortcode( 'byline', '<div class="byline">' . __('Posted <em>by</em> [entry-author] <em>on</em> [entry-published] [entry-comments-link before=" . "] [entry-edit-link before=" . "]', 'good' ) . '</div>'); ?>

						<div class="entry-content">
							<?php the_excerpt(); ?>
						</div><!-- .entry-content -->
						
						<?php echo apply_atomic_shortcode( 'entry_meta', '<p class="entry-meta"><a class="more-link" href="' . get_permalink() . '">' . __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'good' ) . '</a></p>' ); ?>