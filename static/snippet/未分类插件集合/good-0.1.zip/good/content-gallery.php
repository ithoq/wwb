						<?php echo apply_atomic_shortcode( 'entry_title', '[entry-title]' ); ?>

						<?php echo apply_atomic_shortcode( 'byline', '<div class="byline">' . __('Posted <em>by</em> [entry-author] <em>on</em> [entry-published] [entry-comments-link before=" . "] [entry-edit-link before=" . "]', 'good' ) . '</div>'); ?>

						<div class="entry-content">
							<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'good' ) ); ?>
							<?php wp_link_pages( array( 'before' => '<p class="page-links">' . __( 'Pages:', 'good' ), 'after' => '</p>' ) ); ?>
						</div><!-- .entry-content -->
						
						<?php echo apply_atomic_shortcode( 'entry_meta', '<p class="entry-meta"><a href="' . get_permalink() . '">' . __( 'Permalink', 'good' ) . '</a></p>' ); ?>