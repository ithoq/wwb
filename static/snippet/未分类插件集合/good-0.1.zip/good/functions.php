<?php
/**
 * @package Good
 * @subpackage Functions
 * @version 0.1
 * @author Tung Do
 * @copyright Copyright (c) 2012, Tung Do
 * @link http://devpress.com/themes/good
 */

/* Load the core theme framework.  This just loads a library of scripts to handle some dirty work.*/
require_once( trailingslashit( TEMPLATEPATH ) . 'library/hybrid.php' );
$theme = new Hybrid();

/* Do theme setup on the 'after_setup_theme' hook. */
add_action( 'after_setup_theme', 'good_theme_setup' );

/**
 * Theme setup function.  This function adds support for theme features and defines the default theme
 * actions and filters.
 *
 * @since 0.1.0
 */
function good_theme_setup() {

	$prefix = hybrid_get_prefix();
	
	/* Register support for all post formats. */
	add_theme_support(
		'post-formats',
		array(
			'aside',
			'gallery',
			'image',
			'quote',
		)
	);

	/* Registers nav menus for use with the theme.  Remove any that you don't need from the array. */
	add_theme_support( 'hybrid-core-menus', array( 'primary' ) );
	
	/* Register one of Hybrid Core sidebars. */
	add_theme_support( 'hybrid-core-sidebars', array( 'header' ) );
	
	/* Adds Superfish JavaScript for drop-down menus. */
	add_theme_support( 'hybrid-core-drop-downs' );

	/* Register support for advanced widgets. */
	add_theme_support( 'hybrid-core-widgets' );
	
	/* Register support for extra shortcodes. */
	add_theme_support( 'hybrid-core-shortcodes' );

	/* Registers theme settings support and footer editing meta box. */
	add_theme_support( 'hybrid-core-theme-settings', array( 'about', 'footer' ) );
	
	/* Creates a better, custom template hierarchy. */
	add_theme_support( 'hybrid-core-template-hierarchy' ); // important

	/* Add theme support for Hybrid Core framework extensions. */
	add_theme_support( 'breadcrumb-trail' );
	add_theme_support( 'cleaner-gallery' );
	add_theme_support( 'get-the-image' );
	add_theme_support( 'loop-pagination' );
	add_theme_support( 'post-stylesheets' );

	/* Add theme support for auto-feed links in the <head> area. */
	add_theme_support( 'automatic-feed-links' );
	
	/* Load resources into the theme. */
	add_action( 'wp_enqueue_scripts', 'good_resources' );
	
	/* Set content width. */
	hybrid_set_content_width( 600 );
	
	/* Jigoshop-specific functions. */
	if ( function_exists( 'is_jigoshop' ) ) {
		remove_action( 'jigoshop_before_main_content', 'jigoshop_output_content_wrapper', 10);
		remove_action( 'jigoshop_after_main_content', 'jigoshop_output_content_wrapper_end', 10);
		add_action( 'jigoshop_before_main_content', 'good_jigoshop_open_wrapper', 10);
		add_action( 'jigoshop_after_main_content', 'good_jigoshop_close_wrapper', 10);
		
		remove_action( 'jigoshop_before_main_content', 'jigoshop_breadcrumb', 20, 0);

	}

}

/**
 * Loads the theme scripts.
 *
 * @since 0.1
 */
function good_resources() {

	wp_enqueue_script ( 'good-scripts', trailingslashit ( THEME_URI ) . 'js/scripts.js', array( 'jquery' ), '20120107', true );
	
	if( function_exists( 'is_jigoshop') ) {
		wp_dequeue_style('jigoshop_frontend_styles');
		wp_enqueue_style ( 'good-jigoshop', trailingslashit ( THEME_URI ) . 'css/good-jigoshop.css', false, '20111225', 'all' );
	}

}

/**
 * Jigoshop-specific functions.
 *
 * @since 0.1
 */
 
if ( function_exists( 'is_jigoshop') ){

	function good_jigoshop_open_wrapper(){
		echo '<div id="content"><div class="hfeed">';
	}

	function good_jigoshop_close_wrapper(){
		if( is_product_list() ) {
			echo '</div>';
			get_template_part('loop-nav');
			echo '</div>';
		}
		else{
			echo '</div></div>';
		}
	}
	
}