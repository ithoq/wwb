<?php
/**
 * Header Template
 *
 * @package DevPressBase
 * @subpackage Template
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title><?php hybrid_document_title(); ?></title>
	<link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" type="text/css" media="all" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<?php wp_head(); // wp_head ?>
</head>
<body class="<?php hybrid_body_class(); ?>">

	<?php do_atomic( 'open_body' ); // good_open_body ?>

	<div id="container">

		<?php do_atomic( 'before_header' ); // good_before_header ?>

		<div id="header">

			<?php do_atomic( 'open_header' ); // good_open_header ?>

			<div class="wrap">

				<div id="branding">
					<?php hybrid_site_title(); ?>
				</div><!-- #branding -->
				
				<?php get_search_form(); // Loads the searchform.php template. ?>
				
				<?php get_template_part( 'menu', 'primary' ); // Loads the menu-primary.php template. ?>
				
				<?php get_sidebar('header'); // Load the sidebar-header.php template ?>

				<?php do_atomic( 'header' ); // good_header ?>

			</div><!-- .wrap -->

			<?php do_atomic( 'close_header' ); // good_close_header ?>

		</div><!-- #header -->

		<?php do_atomic( 'after_header' ); // good_after_header ?>

		<?php do_atomic( 'before_main' ); // good_before_main ?>

		<div id="main">

			<div class="wrap">

			<?php do_atomic( 'open_main' ); // good_open_main ?>
