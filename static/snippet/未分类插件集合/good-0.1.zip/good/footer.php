<?php
/**
 * Footer Template
 *
 * The footer template is generally used on every page of your site. Nearly all other
 * templates call it somewhere near the bottom of the file. It is used mostly as a closing
 * wrapper, which is opened with the header.php file. It also executes key functions needed
 * by the theme, child themes, and plugins. 
 *
 * @package Good
 * @subpackage Template
 */
?>

				<?php do_atomic( 'close_main' ); // good_close_main ?>

			</div><!-- .wrap -->

		</div><!-- #main -->

		<?php do_atomic( 'after_main' ); // good_after_main ?>

		<?php do_atomic( 'before_footer' ); // good_before_footer ?>

		<div id="footer">

			<?php do_atomic( 'open_footer' ); // good_open_footer ?>

			<div class="wrap">

				<?php echo apply_atomic_shortcode( 'footer_content', hybrid_get_setting( 'footer_insert' ) ); ?>

				<?php do_atomic( 'footer' ); // good_footer ?>

			</div><!-- .wrap -->

			<?php do_atomic( 'close_footer' ); // good_close_footer ?>

		</div><!-- #footer -->

		<?php do_atomic( 'after_footer' ); // good_after_footer ?>

	</div><!-- #container -->

	<?php do_atomic( 'close_body' ); // good_close_body ?>

	<?php wp_footer(); // wp_footer ?>
	
</body>
</html>