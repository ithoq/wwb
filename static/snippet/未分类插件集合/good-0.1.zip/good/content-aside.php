						<?php echo apply_atomic_shortcode( 'byline', '<div class="byline">' . __('Posted <em>by</em> [entry-author] <em>on</em> [entry-published] [entry-comments-link before=" . "] [entry-edit-link before=" . "]', 'good' ) . '</div>'); ?>

						<div class="entry-content">
							<?php the_content(); ?>
						</div><!-- .entry-content -->
						
						<?php echo apply_atomic_shortcode( 'entry_meta', '<p class="entry-meta"><a href="' . get_permalink() . '">' . __( 'Permalink', 'good' ) . '</a></p>' ); ?>